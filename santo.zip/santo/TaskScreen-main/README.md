# TaskScreen
The Task Screen demonstrates a simple Login page consisting Name and Password text fields followed by a "Login" button. The project is composed in "JavaFx"  which is a framework of Java used to build GUI based mobile, desktop and web applications.

![TaskScreen_output](https://user-images.githubusercontent.com/63946717/143676699-c27a652b-fe48-46ae-b814-1b0f90e3afda.PNG)
